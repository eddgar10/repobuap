<?php 

	header("location: ../");

?>